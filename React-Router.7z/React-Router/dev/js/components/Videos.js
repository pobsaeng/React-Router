import React from "react";

export default class Videos extends React.Component {

    render() {
        return (<h1>Videos</h1>);
    }
    
}