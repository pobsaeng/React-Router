import React from "react";
import {browserHistory} from 'react-router'

export default class Blog extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            category: '',
            title: ''
        }
    }
    render() {
        let me = this;
        return (
            <div>
                <h1>Category: {this.state.category}</h1>
                <h1>Title: {this.state.title}</h1>

                <div className="panel">
                    <div className="panel-body">
                        <form onSubmit={(e)=>{
                            const category = e.target.elements[0].value;
                            const title = e.target.elements[1].value;
                            this.setState({ category: category });
                            this.setState({ title: title });
                            }}>
                            <div className="form-row">
                                <label>Category:</label>
                                <input type="text" placeholder="Enter category..."/>
                            </div>
                            <div className="form-row">
                                <label>Title:</label>
                                <input type="text" placeholder="Enter title..."/>
                            </div>
                            <div className="form-row">
                                <label/>
                                <input className="form-item button-secondary" type="submit"/>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        );
    }

}
