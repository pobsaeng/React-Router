import React from "react";

export default class Footer extends React.Component {

    render() {
        return (<h2>- footer here -</h2>);
    }

}
