import React from "react";

export default class Homepage extends React.Component {
    render() {
        return (<h1>Homepage</h1>);
    }
}
