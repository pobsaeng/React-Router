import React from "react";

export default class Forum extends React.Component {
    
    render() {
        return (<h1>Forum</h1>);
    }
    
}